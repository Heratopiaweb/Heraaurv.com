import Link from "next/link";

const properties = [
  {name:"Royal Crown Villa", type:"Luxury Villa", price:"₹12,00,00,000"},
  {name:"Heratopia Grand Hotel", type:"5-Star Hotel", price:"₹48,00,00,000"},
  {name:"Skyline Residence", type:"Premium Residence", price:"₹6,50,00,000"}
];

export default function Home() {
  return (
    <>
      <nav className="nav">
        <div className="brand">HERATO<span>PIA</span></div>
        <div className="navlinks">
          <Link href="/">Home</Link><Link href="/properties">Properties</Link>
          <Link href="/businesses">Businesses</Link><Link href="/leaderboard">Leaderboard</Link>
          <Link href="/login">Login</Link>
        </div>
      </nav>
      <main>
        <section className="hero">
          <div className="container">
            <div className="eyebrow">The Digital Nation</div>
            <h1>Welcome to Heratopia.</h1>
            <p>Explore a fictional nation with premium properties, businesses, citizens, wealth rankings and an expanding digital economy.</p>
            <div className="actions">
              <Link className="btn" href="/dashboard">Enter Dashboard</Link>
              <Link className="btn secondary" href="/properties">Explore Properties</Link>
            </div>
          </div>
        </section>
        <section className="section">
          <div className="container">
            <h2>Featured Properties</h2>
            <div className="grid">
              {properties.map(p=><div className="card" key={p.name}><h3>{p.name}</h3><p className="muted">{p.type}</p><div className="price">{p.price}</div></div>)}
            </div>
          </div>
        </section>
        <section className="section">
          <div className="container grid">
            <div className="card"><div className="stat">1</div><p className="muted">President</p></div>
            <div className="card"><div className="stat">1</div><p className="muted">Co-Owner</p></div>
            <div className="card"><div className="stat">∞</div><p className="muted">Future citizens & businesses</p></div>
          </div>
        </section>
      </main>
      <footer className="footer"><div className="container">© 2026 Heratopia · Fictional digital-world project</div></footer>
    </>
  );
}
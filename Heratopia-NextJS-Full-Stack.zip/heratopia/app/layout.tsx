import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Heratopia",
  description: "The official digital world of Heratopia"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
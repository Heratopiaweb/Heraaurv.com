import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    name: "Heratopia",
    status: "online",
    message: "Heratopia API is running",
    version: "1.0.0"
  });
}
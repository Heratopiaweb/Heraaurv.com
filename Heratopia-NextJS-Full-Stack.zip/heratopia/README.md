# Heratopia — Next.js Full-Stack Starter

## Run locally
1. Install Node.js 20+.
2. Run `npm install`.
3. Run `npm run dev`.
4. Open http://localhost:3000.

## Supabase
Copy `.env.example` to `.env.local`, add your Supabase URL and anon key, then run `supabase/schema.sql` in the Supabase SQL editor.

## Routes
- `/`
- `/properties`
- `/businesses`
- `/leaderboard`
- `/dashboard`
- `/admin`
- `/login`
- `/register`
- `/api/heratopia`

This is a fictional-world project and uses sample financial figures/data until a database is connected.
